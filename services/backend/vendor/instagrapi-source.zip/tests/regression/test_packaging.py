import re
from pathlib import Path

import instagrapi


def test_package_version_matches_pyproject():
    pyproject = Path("pyproject.toml").read_text()
    match = re.search(r'(?m)^version = "([^"]+)"', pyproject)

    assert match is not None
    assert instagrapi.__version__ == match.group(1)


def test_pydantic_dependency_allows_termux_android_wheel_version():
    pyproject = Path("pyproject.toml").read_text()
    required_dependencies = pyproject.split("[project.optional-dependencies]", 1)[0]

    assert "\"pydantic==2.12.5; sys_platform == 'android'\"" in required_dependencies
    assert "\"pydantic>=2.12.5,<2.15; sys_platform != 'android'\"" in required_dependencies
    assert '"pydantic==2.13.4"' not in required_dependencies


def test_runtime_dependencies_use_compatible_ranges():
    pyproject = Path("pyproject.toml").read_text()
    required_dependencies = pyproject.split("[project.optional-dependencies]", 1)[0]

    assert '"requests>=2.34.2,<3"' in required_dependencies
    assert '"PySocks>=1.7.1,<2"' in required_dependencies
    assert '"Pillow>=13.0.0,<14"' in required_dependencies
    assert '"pycryptodomex>=3.23.0,<4"' in required_dependencies

    assert '"requests==2.34.2"' not in required_dependencies
    assert '"PySocks==1.7.1"' not in required_dependencies
    assert '"Pillow==13.0.0"' not in required_dependencies
    assert '"pycryptodomex==3.23.0"' not in required_dependencies


def test_termux_guide_documents_android_pydantic_core_wheel_index():
    termux_guide = Path("docs/usage-guide/termux.md").read_text()

    assert "https://termux-user-repository.github.io/pypi/" in termux_guide
    assert "pydantic==2.12.5" in termux_guide
