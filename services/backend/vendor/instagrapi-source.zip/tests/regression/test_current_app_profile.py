from instagrapi import config
from tests.helpers import *

EXPECTED_DEFAULT_VERSION_CODE = "1079242191"
EXPECTED_DEFAULT_BLOKS_VERSIONING_ID = "799db3e387d7a21a19c72918b8698b6cd28a1516ade363792c100ed45a0f9f0b"


class CurrentAppProfileRegressionTestCase(unittest.TestCase):
    def test_default_client_uses_current_android_app_profile(self):
        client = Client()

        self.assertEqual(client.device_settings["app_version"], config.DEFAULT_APP_VERSION)
        self.assertEqual(client.device_settings["version_code"], EXPECTED_DEFAULT_VERSION_CODE)
        self.assertEqual(
            client.bloks_versioning_id,
            EXPECTED_DEFAULT_BLOKS_VERSIONING_ID,
        )
        self.assertEqual(
            client.user_agent,
            (
                "Instagram 449.0.0.52.84 Android (34/14; 480dpi; 1344x2992; "
                f"Google/google; Pixel 8 Pro; husky; husky; en_US; {EXPECTED_DEFAULT_VERSION_CODE})"
            ),
        )

    def test_default_device_profile_matches_current_android_baseline(self):
        client = Client()

        self.assertEqual(
            client.device_settings,
            {
                "android_version": 34,
                "android_release": "14",
                "dpi": "480dpi",
                "resolution": "1344x2992",
                "manufacturer": "Google/google",
                "device": "husky",
                "model": "Pixel 8 Pro",
                "cpu": "husky",
                "app_version": "449.0.0.52.84",
                "version_code": EXPECTED_DEFAULT_VERSION_CODE,
                "bloks_versioning_id": EXPECTED_DEFAULT_BLOKS_VERSIONING_ID,
            },
        )

    def test_set_app_can_apply_current_default_profile_explicitly(self):
        client = Client()
        client.set_app("385.0.0.47.74")

        client.set_app(config.DEFAULT_APP_VERSION)

        self.assertEqual(client.device_settings["app_version"], config.DEFAULT_APP_VERSION)
        self.assertEqual(client.device_settings["version_code"], EXPECTED_DEFAULT_VERSION_CODE)
        self.assertEqual(
            client.bloks_versioning_id,
            EXPECTED_DEFAULT_BLOKS_VERSIONING_ID,
        )

    def test_private_headers_use_current_android_transport_values(self):
        client = Client()

        self.assertEqual(client.private.headers["X-FB-HTTP-Engine"], "Tigon/MNS/TCP")
        self.assertEqual(client.private.headers["X-Tigon-Is-Retry"], "False")
        self.assertEqual(client.private.headers["X-IG-Capabilities"], "3brTv10=")
        self.assertEqual(client.private.headers["X-IG-App-ID"], "567067343352427")
        self.assertEqual(client.private.headers["X-Zero-Balance"], "INIT")
        self.assertEqual(client.private.headers["X-Zero-Eh"], "")
        self.assertEqual(client.private.headers["X-Zero-State"], "unknown")
        self.assertEqual(client.private.headers["Zero-HTTP-Network-Interface"], "wifi")
        self.assertEqual(
            client.private.headers["X-Bloks-Version-Id"],
            EXPECTED_DEFAULT_BLOKS_VERSIONING_ID,
        )

    def test_default_private_headers_omit_signed_integrity_values(self):
        client = Client()
        lower_headers = {key.lower() for key in client.private.headers}

        self.assertNotIn("x-meta-zca", lower_headers)
        self.assertNotIn("x-meta-usdid", lower_headers)
        self.assertNotIn("x-ig-attest-params", lower_headers)

    def test_saved_legacy_app_profile_is_not_overridden_by_default(self):
        client = Client(
            {
                "device_settings": {
                    "app_version": "385.0.0.47.74",
                    "version_code": "378906843",
                    "bloks_versioning_id": ("a8973d49a9cc6a6f65a4997c10216ce2a06f65a517010e64885e92029bb19221"),
                },
            }
        )

        self.assertEqual(client.device_settings["app_version"], "385.0.0.47.74")
        self.assertEqual(client.device_settings["version_code"], "378906843")
        self.assertEqual(
            client.bloks_versioning_id,
            "a8973d49a9cc6a6f65a4997c10216ce2a06f65a517010e64885e92029bb19221",
        )

    def test_saved_previous_app_profile_receives_matching_bloks_hash(self):
        client = Client({"device_settings": {"app_version": "448.0.0.0.20", "version_code": "1065560286"}})

        self.assertEqual(client.device_settings["app_version"], "448.0.0.0.20")
        self.assertEqual(client.device_settings["version_code"], "1065560286")
        self.assertEqual(
            client.bloks_versioning_id,
            "0bc46a03e177bfc9bc8d611918815acf248fa9c77754d807d6a5951dc9ce9432",
        )
        self.assertEqual(client.private.headers["X-Bloks-Version-Id"], client.bloks_versioning_id)
        self.assertTrue(client.user_agent.startswith("Instagram 448.0.0.0.20 Android ("))
        self.assertTrue(client.user_agent.endswith("; 1065560286)"))

    def test_override_app_version_replaces_saved_profile_with_current_default(self):
        client = Client(
            {
                "device_settings": {
                    "app_version": "385.0.0.47.74",
                    "version_code": "378906843",
                    "bloks_versioning_id": ("a8973d49a9cc6a6f65a4997c10216ce2a06f65a517010e64885e92029bb19221"),
                },
            }
        )

        client.override_app_version = True
        client.set_app()

        self.assertEqual(client.device_settings["app_version"], config.DEFAULT_APP_VERSION)
        self.assertEqual(client.device_settings["version_code"], EXPECTED_DEFAULT_VERSION_CODE)

    def test_constructor_override_app_version_replaces_saved_profile_with_current_default(self):
        client = Client(
            {
                "device_settings": {
                    "app_version": "385.0.0.47.74",
                    "version_code": "378906843",
                    "bloks_versioning_id": ("a8973d49a9cc6a6f65a4997c10216ce2a06f65a517010e64885e92029bb19221"),
                },
            },
            override_app_version=True,
        )

        self.assertEqual(client.device_settings["app_version"], config.DEFAULT_APP_VERSION)
        self.assertEqual(client.device_settings["version_code"], EXPECTED_DEFAULT_VERSION_CODE)

    def test_unknown_saved_app_without_bloks_hash_uses_current_default_profile(self):
        client = Client(
            {
                "device_settings": {
                    "app_version": "450.0.0.0.1",
                    "version_code": "385511872",
                },
            }
        )

        self.assertEqual(client.device_settings["app_version"], config.DEFAULT_APP_VERSION)
        self.assertEqual(client.device_settings["version_code"], EXPECTED_DEFAULT_VERSION_CODE)
        self.assertEqual(
            client.bloks_versioning_id,
            EXPECTED_DEFAULT_BLOKS_VERSIONING_ID,
        )

    def test_legacy_saved_app_without_bloks_hash_is_not_overridden_by_default(self):
        client = Client(
            {
                "device_settings": {
                    "app_version": "269.0.0.19.301",
                    "version_code": "301484483",
                },
            }
        )

        self.assertEqual(client.device_settings["app_version"], "269.0.0.19.301")
        self.assertEqual(client.device_settings["version_code"], "301484483")
        self.assertIsNone(client.bloks_versioning_id)

    def test_explicit_set_device_preserves_unknown_incomplete_app_profile(self):
        client = Client()
        device = {
            "app_version": "431.0.0.47.82",
            "version_code": "979332773",
        }

        client.set_device(device)

        self.assertEqual(client.device_settings["app_version"], "431.0.0.47.82")
        self.assertEqual(client.device_settings["version_code"], "979332773")
