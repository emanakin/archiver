from tests.helpers import *


class FbSearchRegressionTestCase(unittest.TestCase):
    """Offline regression tests for FbSearchMixin v2 SERP endpoints
    and the typeahead-stream flattener."""

    def _build_client(self):
        client = Client()
        client.__dict__["timezone_offset"] = 10800
        return client

    def test_fbsearch_accounts_v2_omits_page_token_when_absent(self):
        client = self._build_client()
        with mock.patch.object(client, "private_request", return_value={"users": []}) as private_request:
            client.fbsearch_accounts_v2("alice")

        private_request.assert_called_once_with(
            "fbsearch/account_serp/",
            params={
                "search_surface": "account_serp",
                "timezone_offset": 10800,
                "query": "alice",
            },
        )

    def test_fbsearch_accounts_v2_forwards_page_token(self):
        client = self._build_client()
        with mock.patch.object(client, "private_request", return_value={"users": []}) as private_request:
            client.fbsearch_accounts_v2("alice", page_token="abc==")

        params = private_request.call_args.kwargs["params"]
        self.assertEqual(params["page_token"], "abc==")

    def test_fbsearch_reels_v2_forwards_optional_cursors(self):
        client = self._build_client()
        with mock.patch.object(client, "private_request", return_value={}) as private_request:
            client.fbsearch_reels_v2("dance", reels_max_id="next-page", rank_token="rt-x")

        private_request.assert_called_once_with(
            "fbsearch/reels_serp/",
            params={
                "search_surface": "clips_search_page",
                "timezone_offset": 10800,
                "query": "dance",
                "reels_max_id": "next-page",
                "rank_token": "rt-x",
            },
        )

    def test_fbsearch_topsearch_v2_uses_self_rank_token_by_default(self):
        client = self._build_client()
        with mock.patch.object(client, "private_request", return_value={}) as private_request:
            client.fbsearch_topsearch_v2("alice")

        params = private_request.call_args.kwargs["params"]
        # Default rank_token mirrors self.rank_token (computed from
        # user_id + uuid). Just assert the wiring, not a specific value.
        self.assertEqual(params["rank_token"], client.rank_token)
        self.assertEqual(params["search_surface"], "top_serp")
        self.assertNotIn("next_max_id", params)
        self.assertNotIn("reels_max_id", params)

    def test_fbsearch_topsearch_v2_explicit_rank_token_overrides_default(self):
        client = self._build_client()
        with mock.patch.object(client, "private_request", return_value={}) as private_request:
            client.fbsearch_topsearch_v2(
                "alice",
                next_max_id="cursor-1",
                reels_max_id="cursor-2",
                rank_token="custom-rt",
            )

        params = private_request.call_args.kwargs["params"]
        self.assertEqual(params["rank_token"], "custom-rt")
        self.assertEqual(params["next_max_id"], "cursor-1")
        self.assertEqual(params["reels_max_id"], "cursor-2")

    def test_media_search_extracts_media_grid_and_paginates(self):
        client = self._build_client()

        def media(pk):
            return {
                "pk": pk,
                "id": f"{pk}_2",
                "code": f"code-{pk}",
                "taken_at": 1710000000,
                "media_type": 1,
                "user": {
                    "pk": "2",
                    "username": "example",
                    "profile_pic_url": "https://example.com/profile.jpg",
                },
                "image_versions2": {
                    "candidates": [
                        {
                            "url": f"https://example.com/{pk}.jpg",
                            "width": 100,
                            "height": 100,
                        }
                    ]
                },
                "caption": {"text": "space"},
            }

        with mock.patch.object(
            client,
            "fbsearch_topsearch_v2",
            side_effect=[
                {
                    "media_grid": {
                        "sections": [
                            {
                                "layout_content": {
                                    "fill_items": [
                                        {"media": media("1")},
                                        {"media": media("2")},
                                    ]
                                }
                            }
                        ],
                        "has_more": True,
                        "next_max_id": "next-page",
                        "reels_max_id": "next-reels",
                        "rank_token": "next-rank",
                    }
                },
                {
                    "media_grid": {
                        "sections": [
                            {
                                "layout_content": {
                                    "fill_items": [
                                        {"media": media("3")},
                                    ]
                                }
                            }
                        ],
                        "has_more": False,
                    }
                },
            ],
        ) as topsearch:
            medias = client.media_search("space", amount=3)

        self.assertEqual([media.pk for media in medias], ["1", "2", "3"])
        self.assertTrue(all(isinstance(media, Media) for media in medias))
        self.assertEqual(topsearch.call_args_list[0].kwargs, {})
        self.assertEqual(
            topsearch.call_args_list[1].kwargs,
            {
                "next_max_id": "next-page",
                "reels_max_id": "next-reels",
                "rank_token": "next-rank",
            },
        )

    def test_media_search_stops_at_amount_without_next_page(self):
        client = self._build_client()

        def media(pk):
            return {
                "pk": pk,
                "id": f"{pk}_2",
                "code": f"code-{pk}",
                "taken_at": 1710000000,
                "media_type": 1,
                "user": {
                    "pk": "2",
                    "username": "example",
                    "profile_pic_url": "https://example.com/profile.jpg",
                },
                "image_versions2": {
                    "candidates": [
                        {
                            "url": f"https://example.com/{pk}.jpg",
                            "width": 100,
                            "height": 100,
                        }
                    ]
                },
                "caption": {"text": "space"},
            }

        with mock.patch.object(
            client,
            "fbsearch_topsearch_v2",
            return_value={
                "media_grid": {
                    "sections": [
                        {
                            "layout_content": {
                                "fill_items": [
                                    {"media": media("1")},
                                    {"media": media("2")},
                                ]
                            }
                        }
                    ],
                    "has_more": True,
                    "next_max_id": "next-page",
                }
            },
        ) as topsearch:
            medias = client.media_search("space", amount=1)

        self.assertEqual([media.pk for media in medias], ["1"])
        topsearch.assert_called_once_with("space")

    def _media_payload(self, pk):
        return {
            "pk": pk,
            "id": f"{pk}_2",
            "code": f"code-{pk}",
            "taken_at": 1710000000,
            "media_type": 1,
            "user": {
                "pk": "2",
                "username": "example",
                "profile_pic_url": "https://example.com/profile.jpg",
            },
            "image_versions2": {
                "candidates": [
                    {
                        "url": f"https://example.com/{pk}.jpg",
                        "width": 100,
                        "height": 100,
                    }
                ]
            },
            "caption": {"text": "space"},
        }

    def test_media_search_raises_when_media_grid_is_missing(self):
        for payload in ({"status": "ok"}, {"status": "ok", "media_grid": None}):
            with self.subTest(payload=payload):
                client = self._build_client()
                fake_response = mock.Mock(status_code=200)
                client.last_response = fake_response
                with mock.patch.object(client, "fbsearch_topsearch_v2", return_value=payload) as topsearch:
                    with self.assertRaises(PrivateError) as caught:
                        client.media_search("secret-query")

                self.assertIsInstance(caught.exception, ClientError)
                self.assertIs(caught.exception.response, fake_response)
                self.assertEqual(caught.exception.code, 200)
                self.assertNotIn("secret-query", str(caught.exception))
                topsearch.assert_called_once_with("secret-query")

    def test_media_search_raises_when_paginated_page_misses_media_grid(self):
        client = self._build_client()
        with mock.patch.object(
            client,
            "fbsearch_topsearch_v2",
            side_effect=[
                {
                    "media_grid": {
                        "sections": [{"layout_content": {"fill_items": [{"media": self._media_payload("1")}]}}],
                        "has_more": True,
                        "next_max_id": "page-2",
                    }
                },
                {"status": "ok"},
            ],
        ) as topsearch:
            with self.assertRaises(PrivateError):
                client.media_search("space", amount=5)

        self.assertEqual(topsearch.call_count, 2)
        self.assertEqual(topsearch.call_args_list[1].kwargs, {"next_max_id": "page-2"})

    def test_media_search_raises_on_malformed_response_or_grid(self):
        malformed_payloads = [
            None,
            [],
            {"status": "ok", "media_grid": []},
            {"status": "ok", "media_grid": "invalid"},
            {"status": "ok", "media_grid": {"sections": "invalid"}},
            {"status": "ok", "media_grid": {"sections": 123}},
            {"status": "ok", "media_grid": {"sections": {}}},
        ]
        for payload in malformed_payloads:
            with self.subTest(payload=payload):
                client = self._build_client()
                with mock.patch.object(client, "fbsearch_topsearch_v2", return_value=payload):
                    with self.assertRaises(PrivateError):
                        client.media_search("space")

    def test_media_search_returns_empty_list_for_valid_empty_media_grid(self):
        empty_payloads = [
            {"status": "ok", "media_grid": {"sections": [], "has_more": False}},
            {"status": "ok", "media_grid": {}},
            {"status": "ok", "media_grid": {"sections": None, "has_more": False}},
        ]
        for payload in empty_payloads:
            with self.subTest(payload=payload):
                client = self._build_client()
                with mock.patch.object(client, "fbsearch_topsearch_v2", return_value=payload) as topsearch:
                    medias = client.media_search("space")

                self.assertEqual(medias, [])
                topsearch.assert_called_once_with("space")

    def test_media_search_extracts_all_grid_section_shapes_without_pagination_metadata(self):
        client = self._build_client()
        payload = {
            "media_grid": {
                "sections": [
                    {
                        "layout_content": {
                            "one_by_two_item": {
                                "media": self._media_payload("1"),
                                "clips": {"items": [{"media": self._media_payload("2")}]},
                            },
                            "fill_items": [{"media": self._media_payload("3")}],
                            "medias": [{"media": self._media_payload("4")}],
                        }
                    }
                ]
            }
        }
        with mock.patch.object(client, "fbsearch_topsearch_v2", return_value=payload) as topsearch:
            medias = client.media_search("space", amount=10)

        self.assertEqual([media.pk for media in medias], ["1", "2", "3", "4"])
        self.assertTrue(all(isinstance(media, Media) for media in medias))
        topsearch.assert_called_once_with("space")

    def test_media_search_skips_malformed_nodes_and_sections(self):
        client = self._build_client()
        client.logger = mock.Mock()
        payload = {
            "media_grid": {
                "sections": [
                    "invalid-section",
                    {"layout_content": "invalid-layout"},
                    {
                        "layout_content": {
                            "fill_items": [
                                "invalid-item",
                                {"media": {"pk": "broken"}},
                                {"media": self._media_payload("10")},
                            ]
                        }
                    },
                ],
                "has_more": False,
            }
        }
        with mock.patch.object(client, "fbsearch_topsearch_v2", return_value=payload):
            medias = client.media_search("space", amount=5)

        self.assertEqual([media.pk for media in medias], ["10"])
        client.logger.warning.assert_called_once()

    def test_media_search_stops_on_repeated_cursor_and_missing_next_cursor(self):
        client = self._build_client()
        with mock.patch.object(
            client,
            "fbsearch_topsearch_v2",
            side_effect=[
                {
                    "media_grid": {
                        "sections": [{"layout_content": {"fill_items": [{"media": self._media_payload("1")}]}}],
                        "has_more": True,
                        "next_max_id": "cursor-1",
                    }
                },
                {
                    "media_grid": {
                        "sections": [{"layout_content": {"fill_items": [{"media": self._media_payload("2")}]}}],
                        "has_more": True,
                        "next_max_id": "cursor-1",
                    }
                },
                AssertionError("repeated cursor should not trigger another request"),
            ],
        ) as topsearch:
            medias = client.media_search("space", amount=0)

        self.assertEqual([media.pk for media in medias], ["1", "2"])
        self.assertEqual(topsearch.call_count, 2)

        with mock.patch.object(
            client,
            "fbsearch_topsearch_v2",
            side_effect=[
                {
                    "media_grid": {
                        "sections": [{"layout_content": {"fill_items": [{"media": self._media_payload("3")}]}}],
                        "has_more": True,
                        "next_max_id": "",
                    }
                },
                AssertionError("empty cursor should not trigger another request"),
            ],
        ) as topsearch_empty_cursor:
            medias = client.media_search("space", amount=0)

        self.assertEqual([media.pk for media in medias], ["3"])
        self.assertEqual(topsearch_empty_cursor.call_count, 1)

    def test_fbsearch_typehead_flattens_stream_rows(self):
        client = self._build_client()
        with mock.patch.object(
            client,
            "private_request",
            return_value={
                "stream_rows": [
                    {"users": [{"pk": "1"}, {"pk": "2"}]},
                    {"users": [{"pk": "3"}]},
                    {"users": []},
                ]
            },
        ):
            users = client.fbsearch_typehead("ali")

        self.assertEqual([u["pk"] for u in users], ["1", "2", "3"])

    def test_fbsearch_typehead_handles_missing_stream_rows(self):
        client = self._build_client()
        with mock.patch.object(client, "private_request", return_value={}):
            users = client.fbsearch_typehead("ali")

        self.assertEqual(users, [])

    def test_web_search_topsearch_sends_expected_params(self):
        client = self._build_client()
        expected = {"hashtags": []}
        with mock.patch.object(client, "private_request", return_value=expected) as private_request:
            result = client.web_search_topsearch("alice")

        self.assertEqual(result, expected)
        private_request.assert_called_once_with(
            "web/search/topsearch/",
            params={
                "search_surface": "web_top_search",
                "context": "blended",
                "include_reel": "true",
                "query": "alice",
            },
        )

    def test_web_search_topsearch_hashtags_extracts_hashtags(self):
        client = self._build_client()
        with mock.patch.object(
            client,
            "web_search_topsearch",
            return_value={"hashtags": [{"hashtag": {"id": "1", "name": "python", "media_count": 10}}]},
        ):
            hashtags = client.web_search_topsearch_hashtags("python")

        self.assertEqual([hashtag.name for hashtag in hashtags], ["python"])

    def test_search_hashtags_accepts_numeric_private_id(self):
        client = self._build_client()
        with mock.patch.object(
            client,
            "private_request",
            return_value={
                "results": [
                    {
                        "id": 17843915557058484,
                        "name": "restaurant",
                        "media_count": 65043150,
                        "profile_pic_url": None,
                    }
                ]
            },
        ):
            hashtags = client.search_hashtags("restaurant")

        self.assertEqual(hashtags[0].id, "17843915557058484")
        self.assertEqual(hashtags[0].name, "restaurant")
        self.assertEqual(hashtags[0].media_count, 65043150)

    def test_fbsearch_suggested_profiles_extracts_user_short_without_stories(self):
        client = self._build_client()
        with mock.patch.object(
            client,
            "private_request",
            return_value={
                "users": [
                    {
                        "pk": "123",
                        "username": "alice",
                        "full_name": "Alice",
                        "profile_pic_url": "https://example.com/alice.jpg",
                        "is_private": False,
                        "has_anonymous_profile_picture": False,
                    }
                ]
            },
        ) as private_request:
            users = client.fbsearch_suggested_profiles("999")

        private_request.assert_called_once_with(
            "fbsearch/accounts_recs/",
            params={
                "target_user_id": "999",
                "include_friendship_status": "true",
            },
        )
        self.assertIsInstance(users[0], UserShort)
        self.assertEqual(users[0].pk, "123")
        self.assertEqual(users[0].stories, [])

    def test_search_music_skips_non_track_items(self):
        client = self._build_client()
        with mock.patch.object(
            client,
            "private_request",
            return_value={
                "items": [
                    {"artist": {"pk": "123", "username": "hanszimmer"}, "track": None},
                    {"playlist": {"id": "456", "title": "Hans Zimmer Essentials"}},
                    {
                        "track": {
                            "id": "789",
                            "title": "Time",
                            "subtitle": "Hans Zimmer",
                            "display_artist": "Hans Zimmer",
                            "audio_cluster_id": 111,
                            "cover_artwork_uri": None,
                            "cover_artwork_thumbnail_uri": None,
                            "highlight_start_times_in_ms": [0],
                            "is_explicit": False,
                            "dash_manifest": "",
                            "has_lyrics": False,
                            "audio_asset_id": 222,
                            "duration_in_ms": 123000,
                            "allows_saving": True,
                        }
                    },
                ]
            },
        ) as private_request:
            tracks = client.search_music("Hans Zimmer")

        self.assertEqual([track.title for track in tracks], ["Time"])
        private_request.assert_called_once()
        self.assertEqual(private_request.call_args.args[0], "music/audio_global_search/")
        self.assertIn("params", private_request.call_args.kwargs)

    def test_fbsearch_item_forwards_optional_cursors(self):
        client = self._build_client()
        with mock.patch.object(client, "private_request", return_value={"items": []}) as private_request:
            result = client.fbsearch_item(
                "clips_serp_page",
                "clips_serp_page",
                "#dance",
                timezone_offset=10800,
                count=12,
                reels_page_index=2,
                has_more_reels="true",
                reels_max_id="reels-cursor",
                next_max_id="next-cursor",
                rank_token="rank-token",
                page_index=3,
                page_token="page-token",
                paging_token="paging-token",
            )

        self.assertEqual(result, {"items": []})
        private_request.assert_called_once_with(
            "fbsearch/clips_serp_page/",
            params={
                "search_surface": "clips_serp_page",
                "query": "#dance",
                "timezone_offset": 10800,
                "count": 12,
                "reels_page_index": 2,
                "has_more_reels": "true",
                "reels_max_id": "reels-cursor",
                "next_max_id": "next-cursor",
                "rank_token": "rank-token",
                "page_index": 3,
                "page_token": "page-token",
                "paging_token": "paging-token",
            },
        )

    def test_fbsearch_keyword_typeahead_sends_blended_context(self):
        client = self._build_client()
        with mock.patch.object(client, "private_request", return_value={"keywords": []}) as private_request:
            client.fbsearch_keyword_typeahead("ali", timezone_offset=10800, count=5)

        private_request.assert_called_once_with(
            "fbsearch/keyword_typeahead/",
            params={
                "search_surface": "typeahead_search_page",
                "query": "ali",
                "context": "blended",
                "timezone_offset": 10800,
                "count": 5,
            },
        )

    def test_fbsearch_typeahead_stream_sends_blended_context(self):
        client = self._build_client()
        with mock.patch.object(client, "private_request", return_value={"stream_rows": []}) as private_request:
            client.fbsearch_typeahead_stream("ali", timezone_offset=10800, count=5)

        private_request.assert_called_once_with(
            "fbsearch/typeahead_stream/",
            params={
                "search_surface": "typeahead_search_page",
                "query": "ali",
                "context": "blended",
                "timezone_offset": 10800,
                "count": 5,
            },
        )
