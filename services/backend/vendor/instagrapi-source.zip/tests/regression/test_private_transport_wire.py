"""Exercise the optional transport against a real loopback TLS/HTTP2 server."""

import base64
import shutil
import ssl
import subprocess
from io import BytesIO

import pytest
import requests
from urllib3.util import Timeout

curl_cffi = pytest.importorskip("curl_cffi", reason="curl_cffi is required for private transport wire tests")
pytest.importorskip("h2")
pytest.importorskip("cryptography")

from curl_cffi import CurlHttpVersion, CurlOpt, CurlSslVersion, ffi, lib

from instagrapi import Client
from instagrapi.exceptions import ClientConnectionError, ClientThrottledError
from tests.http2_server import LAB_HOST, LAB_JSON, LoopbackServer


@pytest.fixture
def lab(tmp_path, monkeypatch):
    # Curl must never inherit a developer's real proxy during a loopback test.
    for name in ("http_proxy", "https_proxy", "all_proxy", "no_proxy"):
        monkeypatch.delenv(name, raising=False)
        monkeypatch.delenv(name.upper(), raising=False)
    server = LoopbackServer(tmp_path).start()
    try:
        yield server
    finally:
        server.close()


@pytest.fixture
def client(lab):
    client = Client(tls_verify=str(lab.ca_path), request_timeout=0)
    client.private.trust_env = False
    adapter = client.private.get_adapter("https://localhost/")
    adapter.client.curl_options[CurlOpt.RESOLVE] = [f"{LAB_HOST}:{lab.port}:127.0.0.1"]
    try:
        yield client
    finally:
        for session in (client.private, client.public, client.graphql):
            session.close()


def url(lab, path="/lab/ok", host="127.0.0.1"):
    # A literal loopback address avoids curl's HTTPS-record DNS lookups.
    return f"https://{host}:{lab.port}{path}"


def test_actual_clienthello_h2_only_and_connection_reuse(client, lab):
    first = client.private.get(url(lab), timeout=2)
    second = client.private.get(url(lab), timeout=2)

    assert first.json() == second.json() == {"status": "lab-ok"}
    assert [r["alpn_offers"] for r in lab.records] == [["h2"], ["h2"]]
    assert [r["negotiated"] for r in lab.records] == ["h2", "h2"]
    assert [r["connection_id"] for r in lab.records] == [1, 1]
    assert [r["stream_id"] for r in lab.records] == [1, 3]


def test_mixed_alpn_control_still_negotiates_h2_but_has_different_clienthello(client, lab):
    adapter = client.private.get_adapter(url(lab))
    adapter.client.http_version = CurlHttpVersion.V2_0
    response = client.private.get(url(lab), timeout=2)

    assert response.status_code == 200
    assert lab.records[0]["negotiated"] == "h2"
    assert lab.records[0]["alpn_offers"] == ["h2", "http/1.1"]


def test_actual_clienthello_offers_tls13_without_legacy_versions(client, lab):
    for _ in range(2):
        assert client.private.get(url(lab), timeout=2).status_code == 200
    assert [r["supported_versions"] for r in lab.records] == [[0x0304], [0x0304]]
    assert [r["tls_version"] for r in lab.records] == ["TLSv1.3", "TLSv1.3"]
    assert [r["connection_id"] for r in lab.records] == [1, 1]


def test_default_tls_control_negotiates_tls13_but_also_offers_tls12(client, lab):
    adapter = client.private.get_adapter(url(lab))
    adapter.client.curl_options[CurlOpt.SSLVERSION] = CurlSslVersion.DEFAULT
    assert client.private.get(url(lab), timeout=2).status_code == 200
    assert lab.records[0]["tls_version"] == "TLSv1.3"
    assert 0x0303 in lab.records[0]["supported_versions"]


def test_tls12_only_peer_is_rejected_before_sending_http_body(client, lab):
    lab.server.tls.maximum_version = ssl.TLSVersion.TLSv1_2
    with pytest.raises(requests.exceptions.SSLError):
        client.private.post(url(lab), data="synthetic_password=test", timeout=2)
    assert lab.records == []


@pytest.mark.parametrize(
    "body", ["signed_body=SIGNATURE.%7B%22x%22%3A1%7D", b"binary\x00body", BytesIO(b"file\x00body")]
)
def test_exact_prepared_body_and_mobile_headers(client, lab, body):
    expected = body.getvalue() if isinstance(body, BytesIO) else body.encode() if isinstance(body, str) else body
    request = requests.Request(
        "POST",
        url(lab, "/lab/form?encoded=%2F%2B"),
        data=body,
        headers={"X-IG-App-ID": "test-app", "Content-Type": "application/octet-stream", "X-Empty": ""},
    )
    prepared = client.private.prepare_request(request)
    original_headers = dict(prepared.headers)
    response = client.private.send(prepared, verify=str(lab.ca_path), timeout=2)

    assert response.status_code == 200
    assert dict(prepared.headers) == original_headers
    observed = lab.records[0]
    headers = dict(observed["headers"])
    assert base64.b64decode(observed["body_base64"]) == expected
    assert headers[":path"] == "/lab/form?encoded=%2F%2B"
    assert headers["x-ig-app-id"] == "test-app"
    assert headers["x-empty"] == ""
    assert headers["content-type"] == "application/octet-stream"
    assert headers["user-agent"] == client.user_agent


def test_gzip_is_decoded_once_and_raw_stream_stays_compressed(client, lab):
    with client.private.get(url(lab), timeout=2, stream=True) as response:
        assert response.raw.read(2) == b"\x1f\x8b"
    with client.private.get(url(lab), timeout=2, stream=True) as response:
        assert b"".join(response.iter_content(3)) == LAB_JSON
    assert client.private.get(url(lab), timeout=2).json() == {"status": "lab-ok"}


@pytest.mark.parametrize("stream", [False, True])
def test_head_preserves_content_length_without_expecting_a_body(client, lab, stream):
    with client.private.head(url(lab), timeout=2, stream=stream) as response:
        assert response.status_code == 200
        assert int(response.headers["Content-Length"]) > 0
        assert b"".join(response.iter_content(3)) == b""
    assert client.private.get(url(lab), timeout=2).json() == {"status": "lab-ok"}
    assert [dict(record["headers"])[":method"] for record in lab.records] == ["HEAD", "GET"]
    assert [record["connection_id"] for record in lab.records] == [1, 1]


def test_duplicate_cookies_are_replayed_and_cleared_only_by_requests(client, lab):
    first = client.private.get(url(lab), timeout=2)
    assert first.raw.headers.getlist("set-cookie") == [
        "first_cookie=one; Path=/; Secure",
        "second_cookie=two; Path=/; Secure",
    ]
    assert first.cookies.get_dict() == {"first_cookie": "one", "second_cookie": "two"}
    client.private.get(url(lab), timeout=2)
    cookies = dict(lab.records[-1]["headers"])["cookie"]
    assert set(cookies.split("; ")) == {"first_cookie=one", "second_cookie=two"}
    client.private.cookies.clear()
    client.private.get(url(lab), timeout=2)
    assert "cookie" not in dict(lab.records[-1]["headers"])


def test_429_preserves_response_without_automatic_post_retry(client, lab):
    response = client.private.post(url(lab, "/lab/rate-limit"), data="synthetic_password=test", timeout=2)
    assert response.status_code == 429
    assert response.content == b""
    assert response.headers["Retry-After"] == "7"
    assert len(lab.records) == 1


def test_private_request_maps_429_without_retrying_password(client, lab):
    with pytest.raises(ClientThrottledError):
        client.private_request("lab/rate-limit", data={"synthetic_password": "test"}, domain=f"127.0.0.1:{lab.port}")
    assert len(lab.records) == 1


def test_connection_drop_maps_error_without_resubmitting_body(client, lab):
    with pytest.raises(requests.ConnectionError):
        client.private.post(url(lab, "/lab/drop"), data="synthetic_password=test", timeout=2)
    assert len(lab.records) == 1


def test_truncated_http2_stream_maps_to_requests_connection_error(client, lab):
    with pytest.raises(requests.ConnectionError):
        client.private.get(url(lab, "/lab/partial"), timeout=2)
    assert len(lab.records) == 1


def test_private_request_preserves_http2_stream_failure(client, lab):
    with pytest.raises(ClientConnectionError):
        client.private_request("lab/partial", domain=f"127.0.0.1:{lab.port}")
    assert len(lab.records) == 1


def test_curl_partial_file_does_not_resubmit_password(client, monkeypatch):
    from curl_cffi.requests.exceptions import IncompleteRead

    submissions = []

    def partial_file(*args, **kwargs):
        submissions.append(kwargs["data"])
        raise IncompleteRead("Synthetic partial transfer", code=18)

    adapter = client.private.get_adapter("https://i.instagram.com/")
    monkeypatch.setattr(adapter.client, "request", partial_file)
    with pytest.raises(ClientConnectionError):
        client.private_request("synthetic/partial", data={"synthetic_password": "test"})
    assert len(submissions) == 1


def test_per_request_tls_verification_and_ca_path(client, lab):
    with pytest.raises(requests.exceptions.SSLError):
        client.private.get(url(lab), verify=True, timeout=2)
    assert lab.records == []
    assert client.private.get(url(lab), verify=str(lab.ca_path), timeout=2).status_code == 200


def test_loopback_ip_subject_alt_name_is_verified(client, lab):
    assert (
        client.private.get(f"https://127.0.0.1:{lab.port}/lab/ok", verify=str(lab.ca_path), timeout=2).status_code
        == 200
    )
    adapter = client.private.get_adapter(url(lab))
    targets = lib.curl_slist_append(ffi.NULL, f"127.0.0.2:{lab.port}:127.0.0.1:{lab.port}".encode())
    adapter.client.curl_options[CurlOpt.CONNECT_TO] = targets
    try:
        with pytest.raises(requests.exceptions.SSLError):
            client.private.get(f"https://127.0.0.2:{lab.port}/lab/ok", verify=str(lab.ca_path), timeout=2)
    finally:
        adapter.client.curl_options.pop(CurlOpt.CONNECT_TO)
        lib.curl_slist_free_all(targets)
    assert len(lab.records) == 1


def test_insecure_request_does_not_disable_verification_for_later_requests(client, lab):
    assert client.private.get(url(lab), verify=False, timeout=2).status_code == 200
    with pytest.raises(requests.exceptions.SSLError):
        client.private.get(url(lab), verify=True, timeout=2)
    assert len(lab.records) == 1


def test_per_request_timeout_is_honored(client, lab):
    with pytest.raises(requests.Timeout):
        client.private.get(url(lab, "/lab/slow"), timeout=0.05)
    assert len(lab.records) == 1


@pytest.mark.parametrize("timeout", [(None, 0.05), Timeout(connect=0.05, read=0.05)])
def test_unsupported_timeouts_are_rejected_before_network(client, lab, timeout):
    with pytest.raises(ValueError, match="numeric"):
        client.private.get(url(lab, "/lab/slow"), timeout=timeout)
    assert lab.records == []


def test_trust_env_false_does_not_use_curl_environment_proxy(client, lab, monkeypatch):
    monkeypatch.setenv("HTTPS_PROXY", "http://127.0.0.1:1")
    monkeypatch.setenv("ALL_PROXY", "http://127.0.0.1:1")
    assert client.private.get(url(lab), timeout=2).status_code == 200


def test_explicit_proxy_overrides_environment_no_proxy(client, lab, monkeypatch):
    monkeypatch.setenv("NO_PROXY", "*")
    with pytest.raises(requests.ConnectionError):
        client.private.get(url(lab), proxies={"https": "http://127.0.0.1:1"}, timeout=0.2)
    assert lab.records == []


def test_session_proxy_change_is_honored(client, lab):
    assert client.private.get(url(lab), timeout=2).status_code == 200
    client.set_proxy("http://127.0.0.1:1")
    with pytest.raises(requests.ConnectionError):
        client.private.get(url(lab), timeout=0.2)
    assert len(lab.records) == 1


def test_old_libcurl_rejected_before_any_request(monkeypatch):
    monkeypatch.setattr(curl_cffi, "__curl_version__", "libcurl/8.9.1 OpenSSL")
    with pytest.raises(RuntimeError, match=r"libcurl.*8\.10"):
        Client(private_transport="curl")


@pytest.mark.parametrize("variable", ["REQUESTS_CA_BUNDLE", "CURL_CA_BUNDLE"])
def test_requests_controls_whether_to_trust_environment_ca(lab, monkeypatch, variable):
    monkeypatch.delenv("REQUESTS_CA_BUNDLE", raising=False)
    monkeypatch.delenv("CURL_CA_BUNDLE", raising=False)
    monkeypatch.setenv(variable, str(lab.ca_path))
    client = Client(private_transport="curl")
    try:
        client.private.trust_env = False
        with pytest.raises(requests.exceptions.SSLError):
            client.private.get(url(lab), timeout=2)
        assert lab.records == []
        client.private.trust_env = True
        assert client.private.get(url(lab), timeout=2).status_code == 200
    finally:
        for session in (client.private, client.public, client.graphql):
            session.close()


def test_ca_directory_is_honored_and_does_not_leak_to_later_requests(client, lab, tmp_path):
    openssl = shutil.which("openssl")
    if not openssl:
        pytest.skip("openssl rehash is needed for the CA directory fixture")
    ca_directory = tmp_path / "ca-directory"
    ca_directory.mkdir()
    shutil.copyfile(lab.ca_path, ca_directory / "root.pem")
    subprocess.run([openssl, "rehash", str(ca_directory)], check=True, capture_output=True)
    assert client.private.get(url(lab), verify=str(ca_directory), timeout=2).status_code == 200
    with pytest.raises(requests.exceptions.SSLError):
        client.private.get(url(lab), verify=True, timeout=2)
    assert client.private.get(url(lab), verify=str(lab.ca_path), timeout=2).status_code == 200


@pytest.fixture
def hybrid_lab(lab, monkeypatch):
    from tests import http2_server

    original = http2_server.peek_client_hello
    hellos = []

    def require_hybrid_group(sock):
        hello = original(sock)
        hellos.append(hello)
        if 4588 not in hello["supported_groups"]:
            raise ValueError("Peer requires the hybrid group to be advertised")
        return hello

    monkeypatch.setattr(http2_server, "peek_client_hello", require_hybrid_group)
    return lab, hellos


@pytest.mark.parametrize("proxy_scheme", [None, "http", "socks5h"])
def test_hybrid_group_reaches_peer_through_proxy(client, hybrid_lab, proxy_scheme):
    from contextlib import ExitStack

    from tests.http2_server import LoopbackProxy
    from tests.socks5_proxy import LoopbackSocksProxy

    lab, hellos = hybrid_lab
    with ExitStack() as stack:
        if proxy_scheme:
            proxy_type = LoopbackProxy if proxy_scheme == "http" else LoopbackSocksProxy
            proxy = stack.enter_context(proxy_type(lab))
            client.set_proxy(f"{proxy_scheme}://synthetic:password@127.0.0.1:{proxy.port}")
        target = url(lab, host=LAB_HOST) if proxy_scheme else url(lab)
        first = client.private.post(target, data=b"synthetic-body", timeout=2)
        second = client.private.get(target, timeout=2)
        assert first.content == second.content == LAB_JSON
        assert first.raw.version == second.raw.version == 20
        headers = dict(lab.records[0]["headers"])
        assert headers["user-agent"] == client.user_agent
        assert "proxy-authorization" not in headers
        assert base64.b64decode(lab.records[0]["body_base64"]) == b"synthetic-body"
        assert hellos == [
            {"alpn_offers": ["h2"], "supported_groups": [4588, 29, 23, 24], "supported_versions": [0x0304]}
        ]
        assert [r["connection_id"] for r in lab.records] == [1, 1]
        if proxy_scheme:
            assert len(proxy.records) == 1
        if proxy_scheme == "socks5h":
            assert proxy.records[0] == {"hostname": "localhost", "port": lab.port, "authenticated": True}


def test_classical_group_control_fails_without_resubmitting(client, hybrid_lab):
    from tests.socks5_proxy import LoopbackSocksProxy

    lab, hellos = hybrid_lab
    with LoopbackSocksProxy(lab) as proxy:
        client.set_proxy(f"socks5h://synthetic:password@127.0.0.1:{proxy.port}")
        target = url(lab, host=LAB_HOST)
        adapter = client.private.get_adapter(target)
        adapter.client.curl_options[CurlOpt.SSL_EC_CURVES] = "X25519:P-256:P-384"
        with pytest.raises(requests.exceptions.ConnectionError):
            client.private.post(target, data=b"synthetic-body", timeout=2)
        assert len(proxy.records) == len(hellos) == 1
        assert hellos[0]["supported_groups"] == [29, 23, 24]
        assert not lab.records


def test_hybrid_offer_remains_compatible_with_classical_peer(client, lab):
    # Restrict the server to P-256, which must remain in the client's offer.
    lab.server.tls.set_ecdh_curve("prime256v1")
    assert client.private.get(url(lab), timeout=2).content == LAB_JSON
    assert 23 in lab.records[0]["supported_groups"]
    assert lab.records[0]["negotiated"] == "h2"
